msgbox "please note that this WILL force you to restart your computer", vbCritical
dim counter, counter2, oPlayer
counter = 0
counter2 = 0
Set oPlayer = CreateObject("WMPlayer.OCX")
do while counter < 3
	msgbox "hehehe, you're stuck here with me >=]", vbCritical, "RAAAAAAAGH"
	counter = counter + 1
loop
msgbox "okaaay, i'll let you go"
msgbox "=["
do while counter2 < 3
	msgbox "lol, you can't escape from me", vbCritical, "hehehe"
	counter2 = counter2 + 1
loop
msgbox "you shouldn't have done that, the reckoning has come", vbCritical, "oh no..."
oPlayer.URL = "hehehe.MP3"
oPlayer.controls.play 
While oPlayer.playState <> 1 ' 1 = Stopped
  WScript.Sleep 100
Wend
oPlayer.close
do while yaicount < 5
	CreateObject("WScript.Shell").Run "batFile.bat"
	yaicount = yaicount + 1
loop