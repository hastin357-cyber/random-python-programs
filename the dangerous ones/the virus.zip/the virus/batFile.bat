@echo off
start "" "https://www.youtube.com/watch?v=SCaAetNzXIc"